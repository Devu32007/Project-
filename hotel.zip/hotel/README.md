# Hotel
Simle hotel manegment system to perform room booking, check in, check out.
Using HTML, CSS, Bootstrap, PHP, JavaScript 
