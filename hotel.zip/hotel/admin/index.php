<?php  
session_start();  
if (isset($_SESSION["user"])) {  
    header("location: home.php");
    exit;
}  
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>SUN RISE ADMIN</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <div id="clouds">
        <div class="cloud x1"></div>
        <div class="cloud x2"></div>
        <div class="cloud x3"></div>
        <div class="cloud x4"></div>
        <div class="cloud x5"></div>
    </div>

    <div class="container">
        <div id="login">
            <form method="post">
                <fieldset class="clearfix">
                    <p><span class="fontawesome-user"></span>
                        <input type="text" name="user" placeholder="Username" required>
                    </p>
                    <p><span class="fontawesome-lock"></span>
                        <input type="password" name="pass" placeholder="Password" required>
                    </p>
                    <p><input type="submit" name="sub" value="Login"></p>
                </fieldset>
            </form>
        </div> 
    </div>
</body>
</html>

<?php
include('db.php');

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['user'], $_POST['pass'])) {
    $myusername = mysqli_real_escape_string($con, $_POST['user']);
    $mypassword = $_POST['pass']; // No need to escape passwords for hashing

    // Fetch user data from database
    $sql = "SELECT id, pass FROM login WHERE usname = ?";
    $stmt = mysqli_prepare($con, $sql);
    mysqli_stmt_bind_param($stmt, "s", $myusername);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if ($row = mysqli_fetch_assoc($result)) {
        if ($mypassword === $row['pass']) { // Use `password_verify()` if passwords are hashed
            $_SESSION['user'] = $myusername;
            echo '<script>alert("Login successful! Redirecting..."); window.location.href="home.php";</script>';
            exit;
        } else {
            echo '<script>alert("Invalid username or password");</script>';
        }
    } else {
        echo '<script>alert("Invalid username or password");</script>';
    }
}
?>
